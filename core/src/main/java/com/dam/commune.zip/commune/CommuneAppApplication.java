package com.dam.commune;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommuneAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommuneAppApplication.class, args);
	}

}
